package Project.tests;

import java.io.File;
import java.io.FileInputStream;
import java.util.Properties;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.Test;

public class ObjReposEmailFile {
  @Test
  public void TestConfig() throws Exception {
	  
	  //to access property file
	  File src = new File("./Configure/EmailPropertyfile.property");
	  
	  //to read the property file create an obj of properties class
	  FileInputStream fis = new FileInputStream(src);
	  Properties pro = new Properties();
	  
	  //to load property file
	  pro.load(fis);
	  
	  WebDriver	driver = new FirefoxDriver();
	  System.out.println("Hello");
	  String url = pro.getProperty("url");
	
	  driver.get(url);
	  
	  WebElement uname = driver.findElement(By.id(pro.getProperty("username")));
	  WebElement fname = driver.findElement(By.id(pro.getProperty("firstname")));
	  WebElement lname = driver.findElement(By.id(pro.getProperty("lastname")));
	  WebElement pwd = driver.findElement(By.id(pro.getProperty("password")));
	  uname.sendKeys("Capgemini");
	  Thread.sleep(1000);
	  fname.sendKeys("Pratibha");
	  Thread.sleep(1000);
	  lname.sendKeys("Thosar");
	  Thread.sleep(1000);
	  pwd.sendKeys("1234");
	  driver.close();
  }
}
