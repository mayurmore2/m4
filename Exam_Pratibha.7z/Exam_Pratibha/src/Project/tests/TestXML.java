package Project.tests;

import java.io.File;
import java.io.FileInputStream;

import org.dom4j.Document;
import org.dom4j.io.SAXReader;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.remote.server.handler.SendKeys;
import org.testng.annotations.Test;

public class TestXML {
  @Test
  public void verifyEmail() throws Exception{
	  

	  //to access property file
	  File src = new File("./Configure/ObjRep.xml");
	  
	  //to read the property file create an obj of properties class
	  FileInputStream fis = new FileInputStream(src);
	  SAXReader sax=new SAXReader();
	  Document document = sax.read(fis);
	  
	  
		WebDriver driver = new FirefoxDriver();
		driver.get("file:///D:/Users/prthosar/Desktop/email.html");

		
		/*driver.findElement(By.id("txtUserName")).sendKeys("capgemini");
		Thread.sleep(1000);
		driver.findElement(By.id("txtFirstName")).sendKeys("capgemini");
		Thread.sleep(1000);
		driver.findElement(By.id("txtLastName")).sendKeys("capgemini");
		Thread.sleep(1000);
		driver.findElement(By.id("txtPassword")).sendKeys("capgemini");
		Thread.sleep(1000);*/
		driver.findElement(By.id(document.selectSingleNode("//login_Detail/uname").getText())).sendKeys("Pratu");
		Thread.sleep(1000);
		driver.findElement(By.id(document.selectSingleNode("//login_Detail/password").getText())).sendKeys("Pratu123");
		Thread.sleep(1000);
		driver.findElement(By.id(document.selectSingleNode("//login_Detail/fname").getText())).sendKeys("Pratibha");
		Thread.sleep(1000);
		driver.findElement(By.id(document.selectSingleNode("//login_Detail/lname").getText())).sendKeys("Thosar");
		Thread.sleep(1000);
		driver.findElement(By.name("submit")).click();
		driver.close();
  }
}
