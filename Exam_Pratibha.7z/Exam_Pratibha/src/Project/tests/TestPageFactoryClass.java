package Project.tests;



import java.util.concurrent.TimeUnit;

//import junit.framework.Test;



//import org.junit.*;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.*;

import Project.pages.PageFactoryClass;
public class TestPageFactoryClass {
		
	 WebDriver driver;
		@BeforeMethod
		public void open()
		{
			System.out.println("Test is started here!!!!!!!!!!!!");
			driver = new FirefoxDriver();
			driver.get("file:///D:/Users/prthosar/Desktop/email.html");
		}
	
		@Test
		public void verifyLogin() throws Exception
		{
					
			PageFactoryClass flName=PageFactory.initElements(driver,PageFactoryClass.class);
			flName.setFLname("Pratibha","Thosar","1234","123");
			
			driver.findElement(By.id("txtFirstName")).click();
			Thread.sleep(2000);
			
			String alertMsg=driver.switchTo().alert().getText();
			driver.switchTo().alert().accept();
			System.out.println(alertMsg);
			
			flName.clear();

			flName.setFLname("Pratibha","Thosar","1234","1234");
			flName.setFname("Pratu");
		
		
			String head="Email Registration";
			if(head.equals(flName.getHeading())){
				System.out.println("Hello Heading is :"+flName.getHeading());
			}
			else
				System.out.println("byeee"+flName.getHeading());
			
			String title1="Email Registration Form";
			if(title1.equals(flName.getTitle())){
				System.out.println("Hello Title is :"+flName.getTitle());
			}
			else
				System.out.println("byeee"+flName.getTitle());

			//To select Gender
			if(flName.gen.get(0).isSelected())
			{
				Thread.sleep(2000);
				flName.gen.get(1).click();
			}
			else
			{
				flName.gen.get(0).click();
				Thread.sleep(2000);
			}
			
			
			//For drop down list of city
			flName.getSelectOptions().selectByIndex(0);
			Thread.sleep(2000);

			flName.getSelectOptions().selectByIndex(1);
			Thread.sleep(2000);
			
			
			flName.Setemt();
			


		}
		@AfterMethod
		public void End()
		{
			driver.quit();
			WebDriver driver = null;
			System.out.println("End of test!!!!!!!!!!!");
			
			
		}
		
		

}
