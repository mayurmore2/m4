package Project.pages;

import java.util.*;

import org.openqa.selenium.By;
//import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.*;
import org.openqa.selenium.support.ui.Select;

public class PageFactoryClass {
	

	WebDriver driver;
	
	/*@FindBy(id="txtUserName")
	@CacheLookup
	WebElement uname;
	*/
	
	@FindBy(tagName="h1")
	@CacheLookup
	WebElement head;
	
	@FindBy(how=How.NAME,using="gender")
	@CacheLookup
	public List<WebElement> gen;
	
	@FindBy(className="Format1")
	@CacheLookup
	WebElement fname;
	@FindBy(how=How.NAME,using="txtLN")
	@CacheLookup
	WebElement lname;
	
	@FindBy(id="txtPassword")
	@CacheLookup
	WebElement pwd;
	
	@FindBy(id="txtConfPassword")
	@CacheLookup
	WebElement cpwd;
	
	@FindBy(name="City")
	@CacheLookup
	WebElement cit;
	
	@FindBy(css="input[pattern='[A-Z]{1}[a-z]{4,12}']")
	@CacheLookup
	WebElement uname;
	
	@FindBy(name="chkHobbies")
	@CacheLookup
	List<WebElement> emt;	
	
	
	public WebElement getFname() {
		return fname;
	}

	public void setFname(String fname) {
		this.fname.sendKeys(fname);
	}

	public void Setemt() throws Exception
	{

		for(int i=0;i<emt.size();i++)
		{
			if(i==1)
				continue;
			
			emt.get(i).click();
			/*if(emt.get(i).isSelected())
				System.out.println(emt.get(i).getAttribute("value"));*/
			Thread.sleep(1000);

		}
	}
	
	public String getHeading() {
		return head.getText();
	}

	public String getTitle() {
		return driver.getTitle();
	}	
	
	public Select getSelectOptions()
	{
		return new Select(cit);
	}
	
	
	public PageFactoryClass(WebDriver driver) {
		super();
		this.driver = driver;
	}

	public void setFLname(String uname,String lname,String pwd,String cpwd) {
		this.uname.sendKeys(uname);
		this.lname.sendKeys(lname);
		this.pwd.sendKeys(pwd);
		this.cpwd.sendKeys(cpwd);
		
	}
	public void clear()
	{
		uname.clear();
		lname.clear();
		pwd.clear();
		cpwd.clear();
	}

}
